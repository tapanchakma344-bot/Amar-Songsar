package com.amarsongsar.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject

data class Entry(val title: String, val amount: Double, val type: String, val date: String)

class MainActivity : ComponentActivity() {
    private val prefs by lazy { getSharedPreferences("amar_songsar", MODE_PRIVATE) }

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var entries by remember { mutableStateOf(loadEntries()) }
            var title by remember { mutableStateOf("") }
            var amount by remember { mutableStateOf("") }
            var type by remember { mutableStateOf("খরচ") }
            var member by remember { mutableStateOf("আমি") }

            val income = entries.filter { it.type == "আয়" }.sumOf { it.amount }
            val expense = entries.filter { it.type == "খরচ" }.sumOf { it.amount }

            MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF167D58))) {
                Scaffold(
                    topBar = {
                        TopAppBar(
                            title = { Text("আমার সংসার", fontWeight = FontWeight.Bold) }
                        )
                    }
                ) { padding ->
                    LazyColumn(
                        modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        item {
                            Text("পারিবারিক আয়-ব্যয়ের হিসাব", style = MaterialTheme.typography.titleMedium)
                            Spacer(Modifier.height(12.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                SummaryCard("মোট আয়", income, Modifier.weight(1f))
                                SummaryCard("মোট খরচ", expense, Modifier.weight(1f))
                            }
                            Spacer(Modifier.height(8.dp))
                            Card(Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(16.dp)) {
                                    Text("অবশিষ্ট টাকা", style = MaterialTheme.typography.labelLarge)
                                    Text("৳ ${money(income - expense)}", style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        item {
                            Text("নতুন হিসাব যোগ করুন", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("বিবরণ (যেমন: বাজার)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                            OutlinedTextField(value = amount, onValueChange = { amount = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("টাকার পরিমাণ") }, modifier = Modifier.fillMaxWidth(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                            OutlinedTextField(value = member, onValueChange = { member = it }, label = { Text("যিনি হিসাব যোগ করছেন") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                FilterChip(selected = type == "খরচ", onClick = { type = "খরচ" }, label = { Text("খরচ") })
                                FilterChip(selected = type == "আয়", onClick = { type = "আয়" }, label = { Text("আয়") })
                            }
                            Button(
                                onClick = {
                                    val value = amount.toDoubleOrNull()
                                    if (title.isNotBlank() && value != null && value > 0) {
                                        val newEntry = Entry("${title.trim()} • ${member.trim()}", value, type, java.text.SimpleDateFormat("dd-MM-yyyy", java.util.Locale.getDefault()).format(java.util.Date()))
                                        entries = listOf(newEntry) + entries
                                        saveEntries(entries)
                                        title = ""; amount = ""
                                    }
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("হিসাব সংরক্ষণ করুন") }
                            Text("এই প্রাথমিক সংস্করণে হিসাব এই ফোনে সংরক্ষিত হয়।", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        item { Text("সাম্প্রতিক হিসাব", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
                        if (entries.isEmpty()) {
                            item { Text("এখনো কোনো হিসাব যোগ করা হয়নি।") }
                        } else {
                            items(entries) { entry ->
                                Card(Modifier.fillMaxWidth()) {
                                    Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Column(Modifier.weight(1f)) {
                                            Text(entry.title, fontWeight = FontWeight.SemiBold)
                                            Text(entry.date, style = MaterialTheme.typography.bodySmall)
                                        }
                                        Text("${if (entry.type == "আয়") "+" else "−"} ৳ ${money(entry.amount)}",
                                            color = if (entry.type == "আয়") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                                            fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private fun loadEntries(): List<Entry> {
        val raw = prefs.getString("entries", "[]") ?: "[]"
        val array = JSONArray(raw)
        return (0 until array.length()).map { i ->
            val o = array.getJSONObject(i)
            Entry(o.getString("title"), o.getDouble("amount"), o.getString("type"), o.getString("date"))
        }
    }

    private fun saveEntries(entries: List<Entry>) {
        val array = JSONArray()
        entries.forEach {
            array.put(JSONObject().put("title", it.title).put("amount", it.amount).put("type", it.type).put("date", it.date))
        }
        prefs.edit().putString("entries", array.toString()).apply()
    }
}

@Composable
fun SummaryCard(label: String, value: Double, modifier: Modifier = Modifier) {
    Card(modifier) {
        Column(Modifier.padding(14.dp)) {
            Text(label, style = MaterialTheme.typography.labelLarge)
            Text("৳ ${money(value)}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
    }
}

fun money(value: Double): String = "%,.2f".format(java.util.Locale("en", "BD"), value).removeSuffix(".00")
